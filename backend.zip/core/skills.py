"""
core/skills.py
==============
Stage 2 — Skill extraction.

Changes (v6 backport): added is_native_pdf to fix early-exit guard truncation.
Changes (v7): fixed split_ocr_blob greedy consumption bug.

           Problem: longest-first-hit algorithm committed to win=2 "Zendosk AnyDesk"
           matching a compound allowlist entry (e.g. "Zendesk AnyDesk") at score 93,
           consuming both tokens and silently dropping "AnyDesk" as its own skill.

           Fix: check win=1 first. If score >= _SINGLE_TOKEN_CONFIDENCE (85),
           commit immediately without trying longer windows. Only fall through to
           multi-token search when the single token is ambiguous (score < 85).

Changes (v8): fixed emoji/symbol prefix stripping in _SKILL_HEADING_RE and
           _SKILLS_END_RE so headers like "⭐ SKILLS" or "👤 WORK EXPERIENCE"
           are correctly detected. Previously the ^ anchor failed to match
           because non-word characters (emojis, bullets) preceded the keyword.

Changes (v9): fixed _SKILL_HEADING_RE false-positive on words like "Skilled",
           "Skillful", "Skilling", "Skillset" by adding a negative lookahead
           (?!ed|ing|ful|set) after skills? so only bare "Skill" / "Skills"
           headings are matched, not substrings inside prose words.

Changes (v10): rewrote _SKILL_HEADING_RE as a full-line match (keyword + EOL).
           The $ anchor means the heading keyword must be the ONLY meaningful
           content on the line (optional leading emoji/bullet, optional trailing
           colon). This blocks prose lines like "Expertise includes Ethereum..."
           or "Technologies used include React and Node" because they continue
           past the keyword. "expertise" and bare "technologies" are removed
           from the alternation — they appear too often in prose. Only compound
           forms ("Technical Expertise", "Tools & Technologies") are kept.

           Accepted headings (case-insensitive, optional leading symbol/colon):
             Skill / Skills
             Key/Core/Technical/Professional Skills
             Skills & Tools / Skills and Tools
             Skills & Technologies / Skills and Technologies
             Competencies / Competency
             Technical/Core/Key Competencies
             Technical Expertise / Areas of Technical Expertise
             Tools & Technologies / Tools and Technologies
             Technical Proficiencies / Proficiencies / Proficiency

Changes (v11): fixed over-consumption of skills section in PDFs where the
           candidate's name and job title (e.g. "QUENTIN RAMIREZ",
           "LINUX SYSTEMS ADMINISTRATOR") appear as all-caps banner lines
           between the skills list and the WORK EXPERIENCE heading.
           These lines don't match _SKILLS_END_RE (no known section keyword)
           so they were silently included in the extracted skills block.

           Fix: introduced _is_banner_line() helper. When a line is encountered
           after at least one skill has been captured, it is tested against
           three layered checks (structural pattern -> word-shape -> allowlist
           guard). Applied in both is_native_pdf and OCR branches.

Changes (v12): fixed _is_banner_line() false-positive on single-word skill
           acronyms (NLTK, AWS, GIT, DOCKER) and two-word skill phrases
           (Hugging Face, Bash Scripting, REST APIs, Server Administration).

           Problem (single-word): the v11 regex matched any all-caps string
           >= 4 chars with no digits. "NLTK" matched -> loop stopped after
           "Hugging Face", dropping NLTK, Transformers, REST APIs, Git.

           Problem (two-word skill phrases): "Hugging Face" and "Bash Scripting"
           are both Title Case two-word strings -- structurally identical to
           a person's name like "Camille Reyes".

           Fix (layer 1 -- structural): require at least one internal space
           (2+ words). Eliminates single-word acronyms.

           Fix (layer 2 -- word-shape): require every word to be either pure
           Title Case (Xxx) or pure ALL CAPS (XXX). Eliminates tokens like
           "APIs" (mixed), "PyTorch" (camelCase), "scikit-learn" (lowercase).

           Fix (layer 3 -- allowlist guard): if the line fuzzy-matches any
           known skill in the allowlist (score >= 80), treat it as a skill
           and do NOT stop. Catches two-word skill phrases like "Hugging Face"
           and "Server Administration" that pass the structural/shape checks.

Changes (v13): added _CONTACT_LINE_RE to stop kept_lines when a contact-info
           line appears inside the skills block. Affects PDFs where the
           candidate's email, phone, and location (with emoji icons) are
           rendered after the skills list instead of in a sidebar column.
           Without this guard the comma-branch fired on "Cebu City, Philippines"
           and split the entire remainder of the document on commas.
           Triggers: @ symbol, phone-like digit run (7+ chars), contact emoji
           codepoints, or www./http prefix. Applied before _is_banner_line in
           both the is_native_pdf and OCR branches. _EXPERIENCE_LINE_RE also
           promoted to module level (was redundantly re-compiled per call).

Changes (v14): fixed _SKILLS_END_RE false-positive on skill names that begin
           with a section keyword. "Objective-C" starts with "objective" which
           is an alternation in _SKILLS_END_RE. The regex matched at position 0
           of rest, producing an empty block and skills_section_rule_based = "".
           Fix: added negative lookahead (?![\w\-]) after "objective" so it
           only matches the bare heading word, not "Objective-C" or similar.

Changes (v15): removed "projects?" from _SKILLS_END_RE. It was too ambiguous --
           fires on skill-context phrases and is not a reliable hard section
           boundary. Work Experience / Education / Employment are sufficient;
           actual project content is caught by _EXPERIENCE_LINE_RE downstream.

Changes (v16): fixed excess/duplicate skills produced when the LLM splits a
           compound skill like "CAD Software (SolidWorks, AutoCAD)" into its
           parts ("CAD Software", "SolidWorks", "AutoCAD"). Added _is_subsumed()
           cleanup step before return to drop any skill whose lowercase form is
           a substring of a longer already-accepted canonical skill.

Changes (v17): fixed comma-split incorrectly fragmenting parenthetical skills
           like "Process Simulation Software (Aspen HYSYS, Aspen Plus)".
           The comma inside the parentheses was treated as a skill delimiter,
           producing broken fragments ("Process Simulation Software (Aspen",
           "Aspen Plus)") that the LLM and canonicalizer could not match.

           Fix: introduced _protect_parens() and _restore_parens() helpers.
           Before comma-splitting, all parenthesised substrings have their
           internal commas replaced with a unique placeholder. After splitting,
           the placeholder is restored so the full skill phrase is preserved.
           Applied only to the comma-branch of extract_skills_section since
           semicolon, pipe, and bullet branches are not affected by this issue.

Changes (v18): fixed _is_subsumed() incorrectly dropping distinct skills that
           share words with a longer skill via mere substring overlap.

           Problem: "C Programming" was dropped because "c programming" is a
           substring of "embedded c programming" — but these are two separate,
           valid skills. The v16 implementation used a naive `s in other.lower()`
           check which matched on any substring regardless of context.

           Fix: _is_subsumed() now only drops a skill when it appears inside a
           longer skill as a parenthetical fragment — i.e. the matched substring
           is immediately preceded by '(' and followed by ',' or ')'. This is
           the only case where a skill is a true split artifact (e.g. "SolidWorks"
           split out of "CAD Software (SolidWorks, AutoCAD)").

           Word-overlap between semantically distinct skills (e.g. "C Programming"
           and "Embedded C programming") no longer triggers a drop. Both skills
           are preserved in discovered_skills, matching skills_section_rule_based.

Changes (v19): fixed skills_section_rule_based truncation and LLM corruption
           caused by line-wrapped parenthetical skills in PDFs.

           Problem: skills like "GIS (Geographic Information Systems)" and
           "GNSS (Global Navigation Satellite System)" are sometimes rendered
           with a line break inside the parentheses in the raw PDF text:

               GIS (Geographic Information
               Systems)

               GNSS (Global Navigation Satellite
               System)

           _protect_parens correctly captured the multi-line parenthetical as
           one unit (since [^)] matches \n), so the entries list was built
           correctly. However, the final ", ".join(entries) embedded the \n
           inside those entries into the output string, causing two cascading
           failures:

           Failure 1 — LLM corruption: the section string passed to the LLM
           contained embedded newlines, so the LLM saw three broken lines
           instead of 8 comma-separated skills:
               "...GIS (Geographic Information"        <- looks like open paren
               "Systems), GNSS (Global Navigation..."  <- "Systems)" looks like garbage
               "System), Remote Sensing, ..."
           The LLM dropped ArcGIS, Land Surveying Techniques, and Technical
           Reporting, and hallucinated "UI Systems" from the broken "Systems)"
           fragment.

           Failure 2 — Output truncation: the skills_section_rule_based JSON
           string appeared to stop at "Remote Sensing" when rendered, because
           the \n inside "GNSS (Global Navigation Satellite\nSystem)" created
           a visual line break that looked like the string had ended.

           Fix: added a normalize_entry() step immediately before the final
           ", ".join(entries) return. Each entry has its internal whitespace
           (including \n) collapsed to a single space and stripped. This
           produces clean single-line skill names like:
               "GIS (Geographic Information Systems)"
               "GNSS (Global Navigation Satellite System)"
           Applied to all branch paths (comma, semicolon, pipe, bullet,
           multi-line, blob) uniformly.

Changes (v20): treat blank-line separators (\\n\\n) between skills as commas,
           routing them into the robust comma-split branch.

           Problem: some PDF resume styles separate each skill with a blank
           line rather than a comma, bullet, pipe, or semicolon:

               AutoCAD Civil 3D

               Topographic Mapping

               GIS (Geographic Information
               Systems)

               GNSS (Global Navigation Satellite
               System)

           The kept_lines loop strips all blank lines before branch detection,
           so by the time joined_block is built the \\n\\n separators are gone.
           The block then falls into the multi-line branch which returns each
           raw line as-is — splitting the line-wrapped parentheticals into
           broken fragments ("GIS (Geographic Information", "Systems)", etc.).

           Fix: added _normalize_double_newlines() helper, applied to `block`
           BEFORE the kept_lines loop.  It protects parenthetical spans
           (including those containing a single internal \\n from PDF line-
           wrapping), replaces every run of 2+ newlines with ', ', then
           restores the protected spans.  This converts the blank-line layout
           into a standard comma-separated string, which the existing comma
           branch + _protect_parens + _normalize_entry pipeline handles
           correctly, producing clean entries like:
               "GIS (Geographic Information Systems)"
               "GNSS (Global Navigation Satellite System)"

Changes (v21): fixed GIS, GNSS, and "Land Surveying Techniques" being dropped
           from discovered_skills despite appearing correctly in
           skills_section_rule_based.  Two distinct root causes:

           Root cause 1 — parenthetical expansion mismatch (GIS, GNSS):
           The section string passed to the LLM now correctly contains the
           full skill names: "GIS (Geographic Information Systems)" and
           "GNSS (Global Navigation Satellite System)".  The LLM faithfully
           preserves these full forms in its output.  However, the jobs
           corpus allowlist stores only the bare acronyms: "GIS", "GNSS".
           After normalize(), "gis geographic information systems" scores
           ~18 against "gis" — far below the 75 threshold — so both skills
           are dropped by the canonicalize allowlist guard.

           Fix: added _strip_paren_expansion() helper, applied to each LLM
           skill string before canonicalize().  It removes trailing
           parenthetical expansions ("GIS (Geographic Information Systems)"
           -> "GIS") so the bare acronym is what gets matched against the
           allowlist.  This does NOT affect skills_section_rule_based, which
           keeps the full parenthetical form for display.

           Root cause 2 — off-by-one fuzzy threshold (Land Surveying Techniques):
           The allowlist has "Land Surveying"; the resume has "Land Surveying
           Techniques".  fuzz.ratio and fuzz.token_sort_ratio both score 71.79
           — just below the 75 threshold.  However fuzz.partial_ratio scores
           100 because the allowlist term is fully contained as a substring of
           the skill.  The canonicalize() call did not include partial_ratio.

           Fix: added fuzz.partial_ratio to the score computation inside the
           LLM output processing loop, alongside the existing ratio and
           token_sort_ratio checks.  partial_ratio is also applied in the
           allowlist-drop guard so the same logic is consistent.

Changes (v22): fixed _is_banner_line firing on legitimate Title Case skill
           names like "Land Surveying Techniques" and "Technical Reporting"
           that appear after a blank line in a one-skill-per-line native PDF.
           These are structurally indistinguishable from name/title banners
           (two or more Title Case words, no digits, not in allowlist) so the
           banner check stopped the loop and silently dropped every skill after
           the first banner false-positive.

           Root cause: the banner check was running on every non-empty line,
           including lines that are clearly still inside the skills list. A
           true banner only appears at a paragraph boundary — after a blank line
           that separates the skills block from a following section.

           Fix: introduced `after_blank` flag in both the is_native_pdf and OCR
           branches. The flag is set True when a blank line is seen and reset
           False after the next non-empty line is appended. _is_banner_line is
           called only when `after_blank` is True, so mid-list Title Case skill
           names are never tested against the banner heuristic.

Changes (v23): fixed Stage 3 NLP matching failing to match GIS, GNSS, and
           "Land Surveying" against the candidate's extracted skills even
           though all three appear correctly in skills_section_rule_based.

           Root cause: Stage 3 consumes skills_section_rule_based by calling
           split_skills_section_rule_based() and then matching each token
           against the job's required_skills list using NLP similarity. The
           tokens "GIS (Geographic Information Systems)" and "GNSS (Global
           Navigation Satellite System)" score too low against allowlist
           entries "GIS" / "GNSS" because the parenthetical expansion inflates
           the string length and dilutes the similarity score. Similarly,
           "Land Surveying Techniques" scores below threshold against
           "Land Surveying" because the extra word "Techniques" reduces
           ratio/token_sort_ratio below the match threshold.

           Fix: updated split_skills_section_rule_based() to return a list of
           SkillToken namedtuples instead of plain strings. Each SkillToken
           carries two fields:
             - display: the full original string for output/UI
               e.g. "GIS (Geographic Information Systems)"
             - match:   the paren-stripped, partial-ratio-ready form for NLP
               e.g. "GIS"
           Stage 3 must use token.match for similarity scoring and
           token.display for output. This keeps display fidelity intact while
           ensuring matching uses the compact form that scores correctly.

           _strip_paren_expansion() is reused for the match field — already
           proven correct in the v21 LLM path.

Changes (v24): removed LLM from the skill discovery path entirely.

           Problem: discover_skills_dynamically() passed skills_section_rule_based
           to a Llama LLM for extraction. The LLM frequently fragmented compound
           skill names — e.g. "AutoCAD Civil 3D" was split into "AutoCAD",
           "Civil 3D", AND "AutoCAD Civil 3D" — producing duplicate/hallucinated
           entries in discovered_skills. The LLM also introduced skills not
           present in the resume ("C++", "IoT Systems") from its training priors.

           Fix: replace the LLM call and its post-processing block with direct
           per-comma token validation using split_skills_section_rule_based().
           Each SkillToken.match is passed through apply_ocr_corrections() ->
           canonicalize() -> partial_ratio rescue (v21 logic), identical to the
           former LLM post-processing path. direct_scan_section() fallback and
           fuzzy_scan() last-resort are preserved unchanged.

           Result: discovered_skills is now a strict subset of
           skills_section_rule_based entries that pass allowlist validation.
           No LLM fragmentation, no hallucinated skills from model priors,
           no redundant compound + fragment duplicates.
"""

from __future__ import annotations

import logging
import re
from typing import NamedTuple

from rapidfuzz import fuzz

from config import BLOB_FUZZY_THRESHOLD
from core.utils import (
    normalize,
    llm_extract_list,
    build_allow_norm_sorted,
    canonicalize,
    direct_scan_section,
    fuzzy_scan,
)
from core.ocr_correction import (
    OcrCorrector,
    build_ocr_corrector,
    apply_ocr_corrections,
)

log = logging.getLogger(__name__)

_cached_allowlist: list[str] = []

# If win=1 scores >= this, commit immediately without trying longer windows.
_SINGLE_TOKEN_CONFIDENCE: int = 85

_SKILL_HEADING_RE = re.compile(
    r"^[^\w]*"                                                   # leading emoji/bullet/whitespace
    r"(?:"
    r"(?:key\s+|core\s+|technical\s+|professional\s+)?skills?"  # Skill, Skills, Key Skills, Technical Skills
    r"(?:\s*(?:&|and)\s*(?:tools?|technologies?))?"             #   optionally suffixed with & Tools / & Technologies
    r"|(?:technical\s+|core\s+|key\s+)?competenc(?:ies|y)"     # Competencies, Technical Competencies, Core Competencies
    r"|(?:areas?\s+of\s+)?technical\s+expertise"                # Technical Expertise, Areas of Technical Expertise
    r"|tools?\s*(?:&|and)\s*technologies?"                      # Tools & Technologies, Tools and Technologies
    r"|(?:technical\s+)?proficienc(?:ies|y)"                    # Proficiencies, Proficiency, Technical Proficiencies
    r")"
    r"\s*:?\s*$",                                               # optional colon -> must end the line here
    re.I | re.M,
    )

# v15: removed "projects?" -- too ambiguous as a section boundary.
# v14: added (?![\w\-]) after "objective" to avoid matching "Objective-C".
_SKILLS_END_RE = re.compile(
    r"^\s*[^\w]*(certifications?|licen[cs]es?\s*(&|and)?\s*certifications?|"
    r"professional\s+certifications?|credentials?|accreditations?|"
    r"work\s+experience|experience|education|employment|awards?|publications?|"
    r"references?|volunteer|languages?|interests?|activities|summary|objective(?![\w\-]))",
    re.I | re.M,
    )

_BANNER_STRUCT_RE = re.compile(
    r"^[A-Za-záéíóúñüÁÉÍÓÚÑÜ][A-Za-záéíóúñüÁÉÍÓÚÑÜ\s\-]{4,59}$"
)

_CONTACT_LINE_RE = re.compile(
    r"@"
    r"|(?:\+?[\d\s\-\(\)]{7,})"
    r"|[\U00002709\U0000260E\U0001F4DE\U0001F4E7\U0001F4E9\U0001F4CC\U0001F4CD\U0001F4F1]"
    r"|\b(?:www\.|http)",
    re.I,
)

_EXPERIENCE_LINE_RE = re.compile(
    r"\b(19|20)\d{2}\b"
    r"|present|current"
    r"|\b(developed?|managed?|led|built|designed?|implemented?|integrated?|"
    r"optimized?|maintained?|participated?|created?|delivered?|deployed?|"
    r"automated?|reduced?|improved?|increased?|collaborated?|coordinated?)\b",
    re.I,
)

_SKILLS_SYSTEM = (
    "You are a precision resume parser. Your task is to identify professional skills. "
    "1. Look for the 'SKILLS' section in the text and extract those items first. "
    "2. Cross-reference with the 'WORK EXPERIENCE' to validate and find additional tools mentioned. "
    "3. IGNORE single-letter artifacts (like 'C', 'R') or two-letter acronyms (like 'AI', 'ML') "
    "UNLESS they are clearly written as distinct skills in the document. "
    "4. Format as a JSON array of strings. Standardize names (e.g., 'Microson' to 'Microsoft'). "
    "Output ONLY the JSON array."
)


# ---------------------------------------------------------------------------
# SkillToken: display + match form for Stage 3 consumption  (v23)
# ---------------------------------------------------------------------------

class SkillToken(NamedTuple):
    """
    A skill extracted from skills_section_rule_based, carrying two forms:

    display -- the full original string, used for UI / output.
               e.g. "GIS (Geographic Information Systems)"

    match   -- the paren-stripped compact form, used for NLP similarity
               scoring against the jobs corpus allowlist.
               e.g. "GIS"

    Stage 3 must use `token.match` for all similarity comparisons and
    `token.display` when writing results back to the output JSON.
    """
    display: str
    match:   str


# ---------------------------------------------------------------------------
# Parenthesis protection helpers (v17)
# ---------------------------------------------------------------------------

def _protect_parens(text: str) -> tuple[str, dict[str, str]]:
    """
    Replace commas inside parentheses with a unique placeholder so they are
    not treated as skill delimiters during comma-splitting.

    Example:
        "Process Simulation Software (Aspen HYSYS, Aspen Plus), AutoCAD"
        ->
        "Process Simulation Software __PAREN_0__, AutoCAD"
        pmap = {"__PAREN_0__": "(Aspen HYSYS, Aspen Plus)"}

    Returns the protected text and the placeholder->original mapping.
    """
    placeholder_map: dict[str, str] = {}

    def replacer(m: re.Match) -> str:
        key = f"__PAREN_{len(placeholder_map)}__"
        placeholder_map[key] = m.group(0)
        return key

    protected = re.sub(r"\([^)]*\)", replacer, text)
    return protected, placeholder_map


def _restore_parens(text: str, placeholder_map: dict[str, str]) -> str:
    """Restore placeholders back to their original parenthesised strings."""
    for key, original in placeholder_map.items():
        text = text.replace(key, original)
    return text


# ---------------------------------------------------------------------------
# Entry normalisation helpers (v19, v20, v21)
# ---------------------------------------------------------------------------

def _normalize_entry(entry: str) -> str:
    """
    Collapse any internal newlines and runs of whitespace inside a skill
    entry into a single space, then strip leading/trailing whitespace.
    """
    return re.sub(r"\s+", " ", entry).strip()


def _normalize_double_newlines(text: str) -> str:
    """
    Replace blank-line separators (two or more consecutive newlines) with
    ', ' so that skills separated by blank lines are routed into the
    comma-split branch rather than the multi-line branch.

    Parenthetical spans (which may contain a single internal \\n from PDF
    line-wrapping) are protected before substitution and restored afterwards.
    """
    pmap: dict[str, str] = {}

    def _protect(m: re.Match) -> str:
        key = f"__NN{len(pmap)}__"
        pmap[key] = m.group(0)
        return key

    protected = re.sub(r"\([^)]*\)", _protect, text, flags=re.DOTALL)
    protected = re.sub(r"\n{2,}", ", ", protected)
    for key, val in pmap.items():
        protected = protected.replace(key, val)
    return protected


def _strip_paren_expansion(skill: str) -> str:
    """
    Remove a trailing parenthetical expansion from a skill name so that the
    bare term can be matched against the allowlist.

    Examples:
        "GIS (Geographic Information Systems)"      -> "GIS"
        "GNSS (Global Navigation Satellite System)" -> "GNSS"
        "CAD Software (SolidWorks, AutoCAD)"        -> "CAD Software"
        "AutoCAD Civil 3D"                          -> "AutoCAD Civil 3D"
    """
    return re.sub(r"\s*\([^)]*\)\s*$", "", skill).strip()


# ---------------------------------------------------------------------------
# Public helper: split skills_section_rule_based into SkillTokens  (v19, v23)
# ---------------------------------------------------------------------------

def split_skills_section_rule_based(skills_str: str) -> list[SkillToken]:
    """
    Split a comma-separated skills string from skills_section_rule_based
    into a list of SkillToken(display, match) pairs.

    Commas inside parentheses are respected — "GIS (Geographic Information,
    Systems)" is kept as one token, not split on the internal comma.

    Each token has:
      .display  -- full original string  e.g. "GIS (Geographic Information Systems)"
      .match    -- paren-stripped form   e.g. "GIS"

    Stage 3 MUST use token.match for NLP similarity scoring and token.display
    for writing results to output JSON. Using token.display for scoring causes
    GIS/GNSS and other expanded acronyms to score too low against the allowlist.

    Example
    -------
    Input:
        "AutoCAD Civil 3D, GIS (Geographic Information Systems), Land Surveying Techniques"

    Output:
        [
            SkillToken(display="AutoCAD Civil 3D",                    match="AutoCAD Civil 3D"),
            SkillToken(display="GIS (Geographic Information Systems)", match="GIS"),
            SkillToken(display="Land Surveying Techniques",            match="Land Surveying Techniques"),
        ]
    """
    if not skills_str or not skills_str.strip():
        return []

    protected, pmap = _protect_parens(skills_str)
    parts = re.split(r"\s*,\s*", protected)
    tokens: list[SkillToken] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        display = _restore_parens(part, pmap)
        match   = _strip_paren_expansion(display)
        tokens.append(SkillToken(display=display, match=match))
    return tokens


# ---------------------------------------------------------------------------
# Banner-line detection
# ---------------------------------------------------------------------------

def _is_subsumed(skill: str, others: list[str]) -> bool:
    """
    Return True only when *skill* is a parenthetical fragment that was
    literally split out of a longer skill in *others*.

    v18 fix: only drops a skill when it appears inside a longer skill as a
    parenthetical fragment (preceded by '(' and followed by ',' or ')').
    Word-overlap between semantically distinct skills is NOT treated as
    subsumption.
    """
    s_lower   = skill.lower()
    s_escaped = re.escape(s_lower)
    pattern = re.compile(r'(?<![a-z0-9])' + s_escaped + r'(?![a-z0-9])')

    for other in others:
        if other == skill or other.lower() == s_lower:
            continue
        other_l = other.lower()
        if len(other_l) <= len(s_lower):
            continue
        m = pattern.search(other_l)
        if not m:
            continue
        preceding = other_l[m.start() - 1] if m.start() > 0 else ''
        following = other_l[m.end()]        if m.end() < len(other_l) else ''
        if preceding == '(' and following in (',', ')'):
            return True

    return False


def _is_banner_line(line: str, allowlist: list[str]) -> bool:
    """
    Return True if *line* looks like a personal name or job-title banner
    injected by certain PDF layouts between the skills list and the next
    section heading.

    Three layered checks must ALL pass:
      Layer 1 -- structural: letters/spaces/hyphens only, 2+ words, 5-60 chars.
      Layer 2 -- word shape: every word is pure Title Case or pure ALL CAPS.
      Layer 3 -- allowlist guard: no fuzzy match >= 80 against any known skill.
    """
    if not _BANNER_STRUCT_RE.match(line):
        return False
    if " " not in line:
        return False
    if any(ch.isdigit() for ch in line):
        return False

    for word in line.split():
        w = word.strip("-")
        if not w:
            continue
        is_title_case = w[0].isupper() and w[1:].islower()
        is_all_caps   = w.isupper()
        if not (is_title_case or is_all_caps):
            return False

    if allowlist:
        line_norm = line.lower().strip()
        for skill in allowlist:
            score = max(
                fuzz.ratio(line_norm, skill.lower()),
                fuzz.token_sort_ratio(line_norm, skill.lower()),
            )
            if score >= 80:
                log.debug(f"[BannerCheck] '{line}' scores {score} vs '{skill}' -> treated as skill")
                return False

    return True


# ---------------------------------------------------------------------------
# OCR blob segmentation
# ---------------------------------------------------------------------------

def split_ocr_blob(line: str, allowlist: list[str]) -> list[str]:
    """
    Segment a collapsed single-line OCR blob into individual skill phrases.

    Algorithm (v7 -- confidence-first):
      1. Check win=1. If score >= _SINGLE_TOKEN_CONFIDENCE (85), commit immediately.
      2. Otherwise try all window lengths and commit to the highest scorer.
      3. If nothing clears the threshold, emit the raw token.
    """
    if not allowlist or not line.strip():
        return [line.strip()] if line.strip() else []

    sorted_allow = sorted(allowlist, key=lambda a: len(a.split()), reverse=True)
    norm_allow   = [(normalize(a), a) for a in sorted_allow]
    max_win      = max(len(a.split()) for a in sorted_allow) if sorted_allow else 1

    tokens = line.split()
    n      = len(tokens)
    result: list[str] = []
    i = 0

    while i < n:
        w1_norm = normalize(tokens[i])
        w1_thr  = (BLOB_FUZZY_THRESHOLD - 10 if len(w1_norm) <= 5
                   else BLOB_FUZZY_THRESHOLD - 5 if len(w1_norm) <= 9
        else BLOB_FUZZY_THRESHOLD)

        w1_best_score, w1_best_val = 0, ""
        for akey, aval in norm_allow:
            s = max(fuzz.token_sort_ratio(w1_norm, akey), fuzz.ratio(w1_norm, akey))
            if s > w1_best_score:
                w1_best_score, w1_best_val = s, aval

        if w1_best_score >= _SINGLE_TOKEN_CONFIDENCE:
            log.debug(f"[BlobSplit] i={i} single-token '{tokens[i]}' -> '{w1_best_val}' ({w1_best_score})")
            result.append(w1_best_val)
            i += 1
            continue

        best_score = w1_best_score if w1_best_score >= w1_thr else 0
        best_canon = w1_best_val   if w1_best_score >= w1_thr else None
        best_len   = 1             if w1_best_score >= w1_thr else 0

        for win_len in range(min(max_win, n - i), 1, -1):
            window_norm = normalize(" ".join(tokens[i : i + win_len]))
            if len(window_norm) < 3:
                continue
            wlen = len(window_norm)
            thr  = (BLOB_FUZZY_THRESHOLD - 10 if wlen <= 5
                    else BLOB_FUZZY_THRESHOLD - 5 if wlen <= 9
            else BLOB_FUZZY_THRESHOLD)

            win_best_score, win_best_val = 0, ""
            for akey, aval in norm_allow:
                s = max(fuzz.token_sort_ratio(window_norm, akey), fuzz.ratio(window_norm, akey))
                if s > win_best_score:
                    win_best_score, win_best_val = s, aval

            if win_best_score >= thr and win_best_score > best_score:
                best_score = win_best_score
                best_canon = win_best_val
                best_len   = win_len

        if best_canon:
            log.debug(f"[BlobSplit] i={i} multi-token '{best_canon}' (win={best_len}, score={best_score})")
            result.append(best_canon)
            i += best_len
        else:
            raw_tok = tokens[i].strip(".,;:()[]")
            if raw_tok:
                result.append(raw_tok)
            i += 1

    return result


# ---------------------------------------------------------------------------
# Skills section extraction
# ---------------------------------------------------------------------------

def extract_skills_section(
        text:          str,
        allowlist:     list[str] | None = None,
        is_native_pdf: bool = False,
) -> str:
    """
    Return the skills section as a comma-separated string.
    Each entry is one complete skill phrase, with internal whitespace
    normalised to a single space (v19).

    v20: blank-line separated layouts are converted to comma-separated
    before the kept_lines loop.

    v22: banner check is gated on after_blank — only fires at paragraph
    boundaries, not on every mid-list line, preventing false-positives on
    legitimate Title Case skill names like "Land Surveying Techniques".

    Consumers should use split_skills_section_rule_based() (v23) to split
    the returned string into SkillToken pairs for correct NLP matching.
    """
    m = _SKILL_HEADING_RE.search(text)
    if not m:
        return ""
    rest  = text[m.end():]
    end_m = _SKILLS_END_RE.search(rest)
    block = rest[: end_m.start()].strip() if end_m else rest.strip()

    # v20: convert blank-line skill separators to commas before the
    # kept_lines loop strips them.
    block = _normalize_double_newlines(block)

    raw_lines = block.splitlines()

    effective_allowlist = allowlist if allowlist is not None else _cached_allowlist

    if is_native_pdf:
        # v22: only run banner check at paragraph boundaries (after_blank).
        kept_lines: list[str] = []
        after_blank = False
        for line in raw_lines:
            stripped = line.strip()
            if not stripped:
                after_blank = True
                continue
            if kept_lines and _CONTACT_LINE_RE.search(stripped):
                log.debug(f"[SkillSection/native] Stopping at contact info: {stripped!r}")
                break
            if kept_lines and after_blank and _is_banner_line(stripped, effective_allowlist):
                log.debug(f"[SkillSection/native] Stopping at banner: {stripped!r}")
                break
            kept_lines.append(stripped)
            after_blank = False
    else:
        # v22: same after_blank gate for OCR branch.
        kept_lines: list[str] = []
        after_blank = False
        for line in raw_lines:
            stripped = line.strip()
            if not stripped:
                after_blank = True
                continue
            words = stripped.split()
            if kept_lines and _CONTACT_LINE_RE.search(stripped):
                log.debug(f"[SkillSection] Stopping at contact info: {stripped!r}")
                break
            if kept_lines and after_blank and _is_banner_line(stripped, effective_allowlist):
                log.debug(f"[SkillSection] Stopping at banner: {stripped!r}")
                break
            if (kept_lines
                    and len(words) >= 3
                    and _EXPERIENCE_LINE_RE.search(stripped)):
                break
            kept_lines.append(stripped)
            after_blank = False

    if not kept_lines:
        return ""

    joined_block = "\n".join(kept_lines)
    _BULLET_RE   = re.compile(r"^\s*[\u2022\-\*\u25e6\u25aa]|\s*\d+\.\s+", re.M)
    entries: list[str] = []

    if "," in joined_block:
        protected_block, pmap = _protect_parens(joined_block)
        protected_lines = protected_block.splitlines()
        for line in protected_lines:
            for part in re.split(r"\s*,\s*", line):
                part = _restore_parens(part.strip(), pmap)
                if part:
                    entries.append(part)

    elif ";" in joined_block:
        for line in kept_lines:
            for part in re.split(r"\s*;\s*", line):
                if part.strip():
                    entries.append(part.strip())
    elif "|" in joined_block:
        for line in kept_lines:
            for part in line.split("|"):
                if part.strip():
                    entries.append(part.strip())
    elif _BULLET_RE.search(joined_block):
        for line in kept_lines:
            clean = re.sub(r"^\s*[\u2022\-\*\u25e6\u25aa]\s*|\s*\d+\.\s+", "", line).strip()
            if clean:
                entries.append(clean)
    elif len(kept_lines) > 1:
        entries = [line.strip() for line in kept_lines if line.strip()]
    else:
        blob = kept_lines[0] if kept_lines else ""
        if blob:
            entries = (
                split_ocr_blob(blob, effective_allowlist)
                if effective_allowlist
                else [blob]
            )

    # v19: normalise internal whitespace in every entry so embedded \n from
    # PDF line-wrapping doesn't pollute the output string or LLM prompt.
    return ", ".join(_normalize_entry(e) for e in entries)


# ---------------------------------------------------------------------------
# Main skill discovery entry point
# ---------------------------------------------------------------------------

def discover_skills_dynamically(
        resume_text:   str,
        jobs_corpus:   list[dict],
        extra_skills:  list[str] | None = None,
        is_native_pdf: bool = False,
) -> list[str]:
    """
    Stage 2 -- skill extraction directly from skills_section_rule_based.

    v24: Removed LLM from the discovery path entirely. discovered_skills is
    now derived by splitting skills_section_rule_based on commas (via
    split_skills_section_rule_based) and validating each token against the
    allowlist. This eliminates LLM fragmentation hallucinations like
    "AutoCAD Civil 3D" being split into "AutoCAD" + "Civil 3D" + "AutoCAD Civil 3D".

    Pipeline:
      1. Build corpus allowlist.
      2. Build OcrCorrector.
      3. Extract skills section (is_native_pdf for early-exit guard).
      4. Split section into SkillTokens (one per comma).
      5. Canonicalise each token.match against allowlist (+ partial_ratio rescue).
      6. direct_scan_section() to recover anything the section extractor missed.
      7. fuzzy_scan() last-resort if both produce nothing.
      8. Drop subsumed parenthetical fragments (v18).
    """
    global _cached_allowlist

    allowlist: set[str] = set()
    for job in jobs_corpus:
        allowlist.update(job.get("required_skills", []))
    if extra_skills:
        allowlist.update(extra_skills)
    allowlist_list = sorted(allowlist)
    allow_norm     = {normalize(a): a for a in allowlist_list}
    sorted_pairs   = build_allow_norm_sorted(allowlist_list)
    corrector      = build_ocr_corrector(allowlist_list)

    _cached_allowlist = allowlist_list

    section = (
            extract_skills_section(
                resume_text,
                allowlist=allowlist_list,
                is_native_pdf=is_native_pdf,
            )
            or resume_text[:3000]
    )

    # --- v24: Replace LLM with direct per-comma token validation ---
    # split_skills_section_rule_based() respects parenthetical commas so
    # "CAD Software (SolidWorks, AutoCAD)" stays as one token, not two.
    tokens = split_skills_section_rule_based(section)

    seen:      set[str]  = set()
    canonical: list[str] = []

    for token in tokens:
        # Use token.match (paren-stripped) for allowlist matching so that
        # "GIS (Geographic Information Systems)" -> "GIS" scores correctly.
        corrected = apply_ocr_corrections(token.match, corrector)
        canon     = canonicalize(
            corrected, allow_norm, threshold=75,
            _sorted_pairs=sorted_pairs, corrector=corrector,
        )

        canon_norm     = normalize(canon)
        corrected_norm = normalize(corrected)
        in_allowlist   = canon_norm in allow_norm

        if not in_allowlist and canon_norm == corrected_norm:
            # partial_ratio rescue (v21): catches "Land Surveying Techniques"
            # matching allowlist "Land Surveying" when ratio scores just below 75.
            best_partial, best_partial_val = 0, ""
            for akey, aval in allow_norm.items():
                s = fuzz.partial_ratio(corrected_norm, akey)
                if s > best_partial:
                    best_partial, best_partial_val = s, aval
            if best_partial >= 75:
                canon      = best_partial_val
                canon_norm = normalize(canon)
                log.debug(
                    f"[Skills/token] partial_ratio rescue: "
                    f"{token.display!r} -> {canon!r} ({best_partial})"
                )
            else:
                log.debug(f"[Skills/token] Dropped non-allowlist token: {token.display!r}")
                continue

        cn = normalize(canon)
        if cn and cn not in seen:
            seen.add(cn)
            canonical.append(canon)

    # direct_scan_section recovers skills present in the resume text but
    # missed by the section extractor (e.g. mentioned only in work experience).
    for hit in direct_scan_section(
            section, sorted_pairs, threshold=82, corrector=corrector, allow_norm=allow_norm
    ):
        hn = normalize(hit)
        if hn and hn not in seen:
            seen.add(hn)
            canonical.append(hit)

    if not canonical:
        log.info("[Skills] Token validation + direct scan produced nothing -- fuzzy fallback.")
        canonical = fuzzy_scan(section, allowlist_list)

    # v18: Drop only true parenthetical fragments, not word-overlap siblings.
    canonical = [s for s in canonical if not _is_subsumed(s, canonical)]

    log.info(f"[Skills] {len(canonical)} skills discovered.")
    return canonical