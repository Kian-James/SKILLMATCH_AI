"""
core/extraction.py
==================
Stage 1 — Text acquisition.

Tries PyMuPDF native text first; falls back to EasyOCR when the native
extraction is too short or the file is an image.

Returns (text, ocr_quality_percent, is_native_pdf).

Apple Silicon / macOS note
--------------------------
EasyOCR ships its own torch + libomp. On ARM64 Macs the OpenMP thread pool
can deadlock or segfault during tensor copy operations.  We prevent this by
setting thread-count env vars to 1 BEFORE any torch/numpy import, and by
running each OCR call in a spawned subprocess so that a crash there cannot
kill the whole evaluation run.

Column-layout note
------------------
Two-column resume layouts come in two flavours:

  1. Label-content layout (e.g. left col = "Skills", "Education" headers;
     right col = the actual content for each section).  Reading left-first
     then right-first causes section headers and their content to become
     separated.  Fix: assign each right-col block to its left-col label
     using y-band boundaries — a label owns all right-col blocks whose y
     falls between that label's y and the next label's y.  This is more
     correct than nearest-y assignment (v_interleave_fix), which
     misbucketed content when a section's right-col content started above
     the label (e.g. job entries rendered above the "Skills" sidebar label).

  2. Equal two-column layout (e.g. two parallel job histories side by side).
     Here interleaving would scramble unrelated sentences.  Fix: emit left
     col top-to-bottom, then right col top-to-bottom.

_classify_column_layout() picks the strategy automatically by comparing the
average token count of left-col blocks vs right-col blocks.  If the right col
is >=3x wordier than the left, the left col is a label/header column and we
interleave using y-band boundaries.  Otherwise we fall back to left-first.

The same classifier is applied to both the native PDF path
(_native_pdf_text) and the EasyOCR path (_sort_boxes_reading_order).

Changelog
---------
v_independent_column_banding: replaced per-page banding-then-splitting with
    split-first then per-column banding via _band_column + _process_page.

    Problem: _split_into_bands ran on ALL page blocks before the column split
    was detected.  For true two-column resumes (e.g. Angela Soriano), ALL-CAPS
    words in the right column (e.g. "SKILLS", "CI/CD", "AWS") were misread as
    section headers, fragmenting the page into cross-contaminated bands and
    mixing left-col work-experience content with right-col skill labels.

    Fix: _process_page detects the page-wide column split FIRST, then bands
    each column independently.  Three explicit paths:
      1. No split  → single-column; band whole page, emit top-to-bottom.
      2. interleave → sidebar layout; _interleave_columns as before.
      3. left_first → equal two-column; band each column independently,
         emit left col then right col.

v_preheader_fix: right-col blocks above the first left label are now emitted
    first as a pre-header, instead of being silently dropped into bucket 0.

    Problem: resume layouts like Quinzel Abad's render the candidate name and
    job title as large blocks in the RIGHT column, above the first left sidebar
    label (e.g. "CONTACT INFO" at y=139).  The old bucket-0 default buried
    those blocks after the first label instead of placing them at the top.

    Fix: _interleave_columns splits right_sorted into pre_header (y < first
    left label y) and body.  pre_header is emitted first (top-to-bottom);
    body proceeds through normal y-band bucket assignment.

v_interleave_fix: replaced nearest-y bucket assignment in _interleave_columns
    with y-band boundary assignment.

    Problem: nearest-y incorrectly bucketed right-col blocks under the wrong
    left-col label when a section's content in the right column started at a
    y coordinate closer to the PREVIOUS left label than to its own label.

    Concrete failure (Kevin Garcia resume):
      Left labels:  Kevin/Garcia (y=58), Electrical Estimator (y=121),
                    Work Experience (y=222), Skills (y=420), Education (y=574)
      Skills items: y=463-568 (all above Education label at y=574)
      DMCI content: y=337-410 (above Skills label at y=420)

      Nearest-y result:
        "Skills" label (y=420) was nearest to DMCI content (y=337-410, dist≈10-83)
        vs Skills items (y=463-568, dist≈43-148) -> DMCI content mis-assigned to
        Skills bucket; actual skills split across Skills+Education buckets.

      y-band result:
        "Work Experience" (y=222) owns right blocks with y in [222, 420) -> DMCI ✓
        "Skills"          (y=420) owns right blocks with y in [420, 574) -> all 7 skills ✓
        "Education"       (y=574) owns right blocks with y in [574, ∞)   -> degree ✓

    Fix: each left label is assigned a y-band [label.y, next_label.y). Every
    right-col block is placed in the band whose lower bound is <= block.y and
    whose upper bound is > block.y. Right-col blocks that appear above the
    first left label are assigned to the first label's bucket.
"""

from __future__ import annotations

# Must be set before torch / numpy are imported anywhere in this process
import os
os.environ.setdefault("OMP_NUM_THREADS",      "1")
os.environ.setdefault("MKL_NUM_THREADS",      "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS",  "1")

import json
import logging
import multiprocessing
import re
import tempfile

import fitz          # PyMuPDF
import numpy as np

from config import OCR_LANGUAGES, MIN_NATIVE_CHARS

log = logging.getLogger(__name__)

_ocr_reader = None

_STANDALONE_BULLET_RE = re.compile(r"(?m)^[ \t]*[•◦▪\-\*][ \t]*$")

# Section headers are fully ALL-CAPS short lines (1–5 words, alpha + & /).
# Title-case lines are intentionally excluded: company names, skill names,
# and job titles all use Title Case and must NOT be treated as boundaries.
# Examples that match:  SUMMARY, WORK EXPERIENCE, SKILLS, R&D EXPERIENCE
# Examples that don't:  Rica Mendoza, Analog Devices, Schematic Review
_SECTION_HEADER_MAX_WORDS = 5


def _is_section_header(text: str) -> bool:
    """Return True when the first line of *text* is an ALL-CAPS section heading."""
    first_line = text.strip().splitlines()[0].strip()
    words = first_line.split()
    if not words or len(words) > _SECTION_HEADER_MAX_WORDS:
        return False
    cleaned = re.sub(r"[&/\s]", "", first_line)
    return bool(cleaned) and cleaned.isupper() and cleaned.isalpha()


def _get_ocr_reader():
    """Lazy-load the EasyOCR reader, pinning torch to single-thread."""
    global _ocr_reader
    if _ocr_reader is None:
        try:
            import torch
            torch.set_num_threads(1)
            torch.set_num_interop_threads(1)
        except Exception:
            pass

        import easyocr
        log.info("[OCR] Loading EasyOCR reader (gpu=False) ...")
        _ocr_reader = easyocr.Reader(OCR_LANGUAGES, gpu=False)
    return _ocr_reader


# ---------------------------------------------------------------------------
# Column-aware reading-order helpers
# ---------------------------------------------------------------------------

def _detect_column_split(x_centers: list[float], page_width: float = 0.0) -> float | None:
    """
    Dynamically detect the x coordinate that divides a two-column layout.

    Sorts all text-box x_centers and looks for the largest gap that falls
    between 20% and 70% of the page width.  Returns None for single-column
    layouts so the caller falls back to plain top-to-bottom ordering.
    """
    if len(x_centers) < 4:
        return None

    xs   = sorted(x_centers)
    span = page_width if page_width > 0 else max(xs)
    if span == 0:
        return None

    best_gap   = 0.0
    best_split: float | None = None

    for i in range(len(xs) - 1):
        gap = xs[i + 1] - xs[i]
        mid = (xs[i] + xs[i + 1]) / 2.0
        if 0.20 * span < mid < 0.70 * span and gap > best_gap:
            best_gap   = gap
            best_split = mid

    if best_split is not None and best_gap > 0.08 * span:
        return best_split
    return None


def _classify_column_layout(
        left: list[tuple[float, float, str]],
        right: list[tuple[float, float, str]],
) -> str:
    """
    Determine how to merge a two-column layout.

    Returns
    -------
    'interleave'
        Left col contains short labels/headers (e.g. "Skills", "Education").
        Each right-col block is assigned to its left-col label by y-band
        boundary, then emitted immediately after that label.

    'left_first'
        Both columns have substantial content (equal two-column layout).
        Emit left col top-to-bottom, then right col top-to-bottom.

    Heuristic
    ---------
    If right-col blocks are >=3x wordier on average than left-col blocks,
    the left col is a label/header column -> 'interleave'.
    """
    if not left or not right:
        return "left_first"

    avg_left  = sum(len(e[2].split()) for e in left)  / len(left)
    avg_right = sum(len(e[2].split()) for e in right) / len(right)

    if avg_left == 0:
        return "left_first"

    ratio = avg_right / avg_left
    log.debug(
        "[ColLayout] avg_left_tokens=%.1f  avg_right_tokens=%.1f  ratio=%.2f",
        avg_left, avg_right, ratio,
    )

    return "interleave" if ratio >= 3.0 else "left_first"


def _interleave_columns(
        left: list[tuple[float, float, str]],
        right: list[tuple[float, float, str]],
) -> list[tuple[float, float, str]]:
    """
    Merge a label-column (left) with a content-column (right).

    v_preheader_fix: right-col blocks that appear above the first left label
    are now emitted first (sorted top-to-bottom) as a pre-header, instead of
    being silently dropped into bucket 0.

    Problem: resume layouts like Quinzel Abad's and Phineas Gutierrez's render
    the candidate name and job title as large blocks in the RIGHT column, above
    the leftmost sidebar label (e.g. "CONTACT INFO" at y=139).  The old code
    defaulted those blocks to bucket 0, so the name/title appeared buried after
    the first left label rather than at the top of the output.

    Fix: split right_sorted into pre_header (y < first_label_y) and body.
    Emit pre_header first (top-to-bottom), then proceed with normal y-band
    bucket assignment for body blocks.
    """
    left_sorted  = sorted(left,  key=lambda e: e[0])
    right_sorted = sorted(right, key=lambda e: e[0])

    if not left_sorted:
        return right_sorted

    first_label_y = left_sorted[0][0]

    # Pre-header: right-col blocks above the first left label (name/title banners)
    pre_header = [rb for rb in right_sorted if rb[0] < first_label_y]
    body_right  = [rb for rb in right_sorted if rb[0] >= first_label_y]

    # Build y-band boundaries: label i owns [left_sorted[i].y, left_sorted[i+1].y)
    # Last label owns [left_sorted[-1].y, +inf)
    buckets: dict[int, list[tuple[float, float, str]]] = {
        i: [] for i in range(len(left_sorted))
    }

    for rb in body_right:
        rb_y     = rb[0]
        assigned = 0

        for i in range(len(left_sorted)):
            label_y      = left_sorted[i][0]
            next_label_y = left_sorted[i + 1][0] if i + 1 < len(left_sorted) else float("inf")
            if label_y <= rb_y < next_label_y:
                assigned = i
                break

        buckets[assigned].append(rb)

    # Emit pre-header blocks first, then each left label followed by its right-col blocks
    ordered: list[tuple[float, float, str]] = sorted(pre_header, key=lambda e: e[0])
    for i, lb in enumerate(left_sorted):
        ordered.append(lb)
        ordered.extend(sorted(buckets[i], key=lambda e: e[0]))

    return ordered


# ---------------------------------------------------------------------------
# Per-column banding and top-level page processor
# ---------------------------------------------------------------------------

def _band_column(entries: list[tuple[float, float, str]]) -> list[list[tuple[float, float, str]]]:
    """
    Partition an already-isolated column's entries into section bands.

    A new band starts whenever a block's first line is an ALL-CAPS section
    header (_is_section_header).  The header block is the first entry of its
    band.  If no headers are found, the entire column is returned as one band.

    Crucially this is called AFTER the page-wide column split, so it only
    ever sees blocks from one column at a time.  This prevents ALL-CAPS words
    in the right column (e.g. skill names like "CI/CD", "AWS") from being
    misread as section headers that would break the left column into bad bands.
    """
    if not entries:
        return []

    sorted_entries = sorted(entries, key=lambda e: e[0])
    bands: list[list[tuple[float, float, str]]] = []
    current_band: list[tuple[float, float, str]] = []

    for entry in sorted_entries:
        _, _, text = entry
        if _is_section_header(text) and current_band:
            bands.append(current_band)
            current_band = [entry]
        else:
            current_band.append(entry)

    if current_band:
        bands.append(current_band)

    return bands


def _process_page(
        entries: list[tuple[float, float, str]],
        page_width: float,
) -> list[tuple[float, float, str]]:
    """
    Top-level reading-order resolver for a single page.

    Detects the page-wide column split FIRST, then chooses one of three paths:

    1. Single-column  — no split detected.
       Band the whole page by ALL-CAPS headers, emit each band top-to-bottom.

    2. Sidebar / label-column  — split found, strategy = 'interleave'.
       _interleave_columns buckets right-col blocks under their left-col
       label using y-band boundaries.

    3. Equal two-column  — split found, strategy = 'left_first'.
       Each column is banded independently by its OWN ALL-CAPS headers,
       then emitted left-col top-to-bottom followed by right-col top-to-bottom.
       Independent banding prevents ALL-CAPS words in the right column from
       fracturing the left column's bands.
    """
    if not entries:
        return []

    x_centers = [e[1] for e in entries]
    col_split  = _detect_column_split(x_centers, page_width)

    if col_split is None:
        # Path 1: single-column
        log.debug("[Page] Single-column layout.")
        ordered: list[tuple[float, float, str]] = []
        for band in _band_column(entries):
            ordered.extend(sorted(band, key=lambda e: e[0]))
        return ordered

    left_col  = [e for e in entries if e[1] <= col_split]
    right_col = [e for e in entries if e[1]  > col_split]
    strategy  = _classify_column_layout(left_col, right_col)
    log.debug("[Page] Two-column layout (strategy=%s, col_split=%.1f)", strategy, col_split)

    if strategy == "interleave":
        # Path 2: sidebar
        return _interleave_columns(left_col, right_col)
    else:
        # Path 3: equal two-column — band each side independently
        ordered = []
        for band in _band_column(left_col):
            ordered.extend(sorted(band, key=lambda e: e[0]))
        for band in _band_column(right_col):
            ordered.extend(sorted(band, key=lambda e: e[0]))
        return ordered


# ---------------------------------------------------------------------------
# Native PDF text extraction
# ---------------------------------------------------------------------------

def _native_pdf_text(file_path: str) -> str:
    """
    Extract text from a native (non-scanned) PDF using PyMuPDF.

    Uses get_text('blocks') so that each text block comes with a bounding
    box, then delegates to _process_page for column-aware reading-order
    resolution.
    """
    doc = fitz.open(file_path)
    pages_text: list[str] = []

    for page in doc:
        page_width = page.rect.width
        blocks     = page.get_text("blocks")   # (x0, y0, x1, y1, text, block_no, block_type)

        entries: list[tuple[float, float, str]] = []
        for b in blocks:
            x0, y0, x1, y1, text, _block_no, block_type = b
            if block_type != 0:
                continue
            text = text.strip()
            if not text:
                continue
            xc = (x0 + x1) / 2.0
            entries.append((y0, xc, text))

        ordered = _process_page(entries, page_width)
        pages_text.append("\n".join(e[2] for e in ordered))

    doc.close()
    return _STANDALONE_BULLET_RE.sub("", "\n".join(pages_text)).strip()


# ---------------------------------------------------------------------------
# EasyOCR column-aware reading-order sort
# ---------------------------------------------------------------------------

def _sort_boxes_reading_order(raw_results: list, page_width: float = 0.0) -> list[str]:
    """
    Convert EasyOCR detail=1 output -> reading-order list of text strings.

    detail=1 returns: (bbox, text, confidence)
    bbox = [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]  (top-left, clockwise)

    Applies the same _process_page logic as the native PDF path so both
    paths produce consistent output.
    """
    if not raw_results:
        return []

    boxes: list[tuple[float, float, str]] = []
    for item in raw_results:
        bbox, text, _conf = item
        x_center = (bbox[0][0] + bbox[2][0]) / 2.0
        y_center = (bbox[0][1] + bbox[2][1]) / 2.0
        if text.strip():
            boxes.append((y_center, x_center, text.strip()))

    if not boxes:
        return []

    if page_width == 0.0:
        page_width = max(b[1] for b in boxes) * 1.1  # rough estimate from content

    ordered = _process_page(boxes, page_width)
    return [b[2] for b in ordered]


# ---------------------------------------------------------------------------
# OCR subprocess worker
# ---------------------------------------------------------------------------

def _ocr_worker(file_path: str, out_file: str) -> None:
    """
    Entry point for the spawned OCR worker process.

    Sets thread-count env vars again before importing torch via easyocr.
    Uses detail=1 + _sort_boxes_reading_order for correct column ordering.
    """
    os.environ["OMP_NUM_THREADS"]      = "1"
    os.environ["MKL_NUM_THREADS"]      = "1"
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["NUMEXPR_NUM_THREADS"]  = "1"

    try:
        import torch
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
    except Exception:
        pass

    reader = _get_ocr_reader()
    lines: list[str] = []

    if file_path.lower().endswith(".pdf"):
        try:
            from pdf2image import convert_from_path
            with tempfile.TemporaryDirectory() as tmpdir:
                pages = convert_from_path(file_path, dpi=200, output_folder=tmpdir)
                for img in pages:
                    img_arr    = np.array(img)
                    page_width = float(img_arr.shape[1])
                    raw        = reader.readtext(img_arr, detail=1, paragraph=False)
                    lines.extend(_sort_boxes_reading_order(raw, page_width))
        except Exception as exc:
            log.warning("[OCR] pdf2image failed (%s); direct image fallback ...", exc)
            try:
                raw   = reader.readtext(file_path, detail=1, paragraph=False)
                lines = _sort_boxes_reading_order(raw)
            except Exception as exc2:
                log.warning("[OCR] Direct fallback also failed (%s).", exc2)
    else:
        try:
            raw   = reader.readtext(file_path, detail=1, paragraph=False)
            lines = _sort_boxes_reading_order(raw)
        except Exception as exc:
            log.warning("[OCR] readtext failed (%s).", exc)

    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(lines, f)


def _ocr_fallback(file_path: str, timeout: int = 120) -> str:
    """
    Run OCR in a spawned child process with a timeout.

    Returns the extracted text, or an empty string if the child crashes,
    times out, or produces no output.
    """
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        out_file = tmp.name

    try:
        ctx = multiprocessing.get_context("spawn")
        p   = ctx.Process(target=_ocr_worker, args=(file_path, out_file))
        p.start()
        p.join(timeout)

        if p.is_alive():
            p.terminate()
            p.join(5)
            log.warning(
                "[OCR] Worker timed out after %ds for %s — skipping OCR.",
                timeout, file_path,
            )
            return ""

        if p.exitcode != 0:
            log.warning(
                "[OCR] Worker exited with code %s for %s — "
                "likely OMP deadlock / segfault, skipping OCR.",
                p.exitcode, file_path,
            )
            return ""

        if not os.path.exists(out_file) or os.path.getsize(out_file) == 0:
            log.warning("[OCR] Worker produced no output for %s.", file_path)
            return ""

        with open(out_file, "r", encoding="utf-8") as f:
            lines = json.load(f)
        return _STANDALONE_BULLET_RE.sub("", "\n".join(lines))

    finally:
        try:
            os.unlink(out_file)
        except OSError:
            pass


def _alnum_ratio(text: str) -> float:
    if not text:
        return 0.0
    return round(sum(c.isalnum() for c in text) / len(text) * 100, 2)


def extract_text(file_path: str) -> tuple[str, float, bool]:
    """
    Stage 1: Try PyMuPDF native text; fall back to EasyOCR.

    Returns
    -------
    (text, ocr_quality_percent, is_native_pdf)
    """
    native = _native_pdf_text(file_path) if file_path.lower().endswith(".pdf") else ""

    if len(native) >= MIN_NATIVE_CHARS:
        log.info("[Stage 1] Native PDF text (%d chars).", len(native))
        return native, _alnum_ratio(native), True

    log.info("[Stage 1] Native text too short — EasyOCR fallback ...")
    ocr_text = _ocr_fallback(file_path)
    quality  = _alnum_ratio(ocr_text)
    log.info("[Stage 1] OCR done (%d chars, quality %.1f%%).", len(ocr_text), quality)
    return ocr_text, quality, False