// lib/screens/full_results_screen.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../models/models.dart';
import '../services/firestore_service.dart';
import '../theme.dart';
import '../widgets/common_widgets.dart';

class FullResultsScreen extends StatefulWidget {
  final ResumeScanRecord record;
  final ResumeUser user;
  final bool fromCache;

  const FullResultsScreen({
    super.key,
    required this.record,
    required this.user,
    required this.fromCache,
  });

  @override
  State<FullResultsScreen> createState() => _FullResultsScreenState();
}

class _FullResultsScreenState extends State<FullResultsScreen> {
  late List<String> _mySkills;
  late List<String> _myCerts;
  final _addSkillCtrl = TextEditingController();
  final _addCertCtrl = TextEditingController();
  final _firestore = FirestoreService();

  @override
  void initState() {
    super.initState();
    _mySkills = List<String>.from(widget.record.skills);
    _myCerts = List<String>.from(widget.record.certs);
  }

  @override
  void dispose() {
    _addSkillCtrl.dispose();
    _addCertCtrl.dispose();
    super.dispose();
  }

  // ── Skill management ──────────────────────────────────────────────────────

  void _addSkill(String skill) {
    final trimmed = skill.trim();
    if (trimmed.isEmpty) return;
    if (_mySkills.map((s) => s.toLowerCase()).contains(trimmed.toLowerCase()))
      return;
    setState(() => _mySkills.add(trimmed));
    _persistSkills();
  }

  void _removeSkill(String skill) {
    setState(() => _mySkills.remove(skill));
    _persistSkills();
  }

  void _addSkillFromField() {
    _addSkill(_addSkillCtrl.text);
    _addSkillCtrl.clear();
  }

  void _persistSkills() {
    final docId = widget.record.id;
    if (docId.isEmpty) {
      debugPrint(
          '[FullResultsScreen] Cannot save skills — record.id is empty.');
      _showSaveWarning('skills');
      return;
    }
    _firestore.updateSkills(docId, List<String>.from(_mySkills)).then((_) {
      debugPrint(
          '[FullResultsScreen] Skills saved to Firestore ($docId): $_mySkills');
    }).catchError((e) {
      debugPrint('[FullResultsScreen] FAILED to save skills: $e');
      if (mounted) _showSaveError('skills', e);
    });
  }

  // ── Cert management ───────────────────────────────────────────────────────

  void _addCert(String cert) {
    final trimmed = cert.trim();
    if (trimmed.isEmpty) return;
    if (_myCerts.map((s) => s.toLowerCase()).contains(trimmed.toLowerCase()))
      return;
    setState(() => _myCerts.add(trimmed));
    _persistCerts();
  }

  void _removeCert(String cert) {
    setState(() => _myCerts.remove(cert));
    _persistCerts();
  }

  void _addCertFromField() {
    _addCert(_addCertCtrl.text);
    _addCertCtrl.clear();
  }

  void _persistCerts() {
    final docId = widget.record.id;
    if (docId.isEmpty) {
      debugPrint('[FullResultsScreen] Cannot save certs — record.id is empty.');
      _showSaveWarning('certifications');
      return;
    }
    _firestore.updateCerts(docId, List<String>.from(_myCerts)).then((_) {
      debugPrint(
          '[FullResultsScreen] Certs saved to Firestore ($docId): $_myCerts');
    }).catchError((e) {
      debugPrint('[FullResultsScreen] FAILED to save certs: $e');
      if (mounted) _showSaveError('certifications', e);
    });
  }

  void _showSaveWarning(String what) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Could not save $what — this scan has no record ID yet. Try again after the scan finishes saving.'),
        backgroundColor: AppTheme.amber500,
      ),
    );
  }

  void _showSaveError(String what, Object error) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Failed to save $what: $error'),
        backgroundColor: AppTheme.red500,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Full Analysis'),
        actions: [
          if (widget.fromCache)
            Container(
              margin: const EdgeInsets.only(right: 16),
              child: const TealBadge(text: 'Cached'),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildScanMeta(context),
            const SizedBox(height: 20),

            // ── Step 1: How we read the resume ───────────────────────────
            _stepHeader(context, '1', 'Resume Reading'),
            const SizedBox(height: 12),
            _buildStep1(context),
            const SizedBox(height: 24),

            // ── Step 2: Skills found ──────────────────────────────────────
            _stepHeader(context, '2', 'Skills Found'),
            const SizedBox(height: 12),
            _buildSkillChips(context),
            const SizedBox(height: 24),

            // ── Step 2B: Certifications ───────────────────────────────────
            _stepHeader(context, '2B', 'Certifications'),
            const SizedBox(height: 12),
            _buildCertChips(context),
            const SizedBox(height: 24),

            // ── Step 3: Career matches ────────────────────────────────────
            _stepHeader(context, '3', 'Best Career Matches'),
            const SizedBox(height: 4),
            Text(
              'Ranked by how well your skills align with each role',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 14),
            _buildTop5(context),
            const SizedBox(height: 24),

            // ── Step 4: System check ──────────────────────────────────────
            _stepHeader(context, '4', 'Analysis Quality Check'),
            const SizedBox(height: 12),
            _buildQualityCheck(context),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  // ── Scan meta header ──────────────────────────────────────────────────────

  Widget _buildScanMeta(BuildContext context) {
    final c = AppColors.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: c.navy800,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.brand.withOpacity(0.25)),
      ),
      child: Row(children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: c.brand.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(Icons.grid_view_rounded, color: c.brand, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.record.fileName,
                style: Theme.of(context).textTheme.titleMedium,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(
              DateFormat('MMM d, yyyy  hh:mm a')
                  .format(widget.record.scannedAt),
              style: GoogleFonts.workSans(fontSize: 11, color: c.textTertiary),
            ),
          ],
        )),
        _modeBadge(context, widget.record.uploadMode),
      ]),
    );
  }

  Widget _modeBadge(BuildContext context, String mode) {
    final c = AppColors.of(context);
    final label = switch (mode) {
      'pdf' => 'PDF',
      'image' => 'Image',
      _ => mode.toUpperCase(),
    };
    final icon = switch (mode) {
      'pdf' => Icons.picture_as_pdf_outlined,
      'image' => Icons.image_outlined,
      _ => Icons.file_present_outlined,
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: c.navy700,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: c.cardBorder),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 13, color: c.textTertiary),
        const SizedBox(width: 5),
        Text(label,
            style: GoogleFonts.workSans(
                fontSize: 11,
                color: c.textTertiary,
                fontWeight: FontWeight.w600)),
      ]),
    );
  }

  // ── Step header ───────────────────────────────────────────────────────────

  Widget _stepHeader(BuildContext context, String number, String title) {
    final c = AppColors.of(context);
    return Row(children: [
      Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: c.brand.withOpacity(0.12),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: c.brand.withOpacity(0.3)),
        ),
        child: Center(
          child: Text(number,
              style: GoogleFonts.fraunces(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: c.brandSoft)),
        ),
      ),
      const SizedBox(width: 10),
      Text(title, style: Theme.of(context).textTheme.titleMedium),
    ]);
  }

  // ── Step 1: Resume reading ────────────────────────────────────────────────

  Widget _buildStep1(BuildContext context) {
    final c = AppColors.of(context);

    final sourceLabel = switch (widget.record.uploadMode) {
      'pdf' => 'PDF file',
      'image' => 'Image file',
      _ => widget.record.uploadMode,
    };

    final qualityLabel = switch (widget.record.uploadMode) {
      'pdf' => 'High quality — text extracted directly',
      _ => 'Good quality — text recognised from image',
    };

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: c.navy800,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.cardBorder),
      ),
      child: Column(children: [
        _metaRow(context, 'Source', sourceLabel),
        Divider(height: 16, color: c.divider),
        _metaRow(context, 'Found',
            '${_mySkills.length} skills  •  ${_myCerts.length} certificates'),
        Divider(height: 16, color: c.divider),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Reading quality',
              style: Theme.of(context).textTheme.bodyMedium),
          Text(
            qualityLabel,
            style: GoogleFonts.workSans(
                fontSize: 12, color: c.brandSoft, fontWeight: FontWeight.w500),
          ),
        ]),
      ]),
    );
  }

  // ── Step 2: Skills (with add input) ──────────────────────────────────────

  Widget _buildSkillChips(BuildContext context) {
    final c = AppColors.of(context);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Add skill input ───────────────────────────────────────────────
      _addItemRow(
        context,
        controller: _addSkillCtrl,
        hint: 'Add a skill to your profile…',
        onAdd: _addSkillFromField,
      ),
      const SizedBox(height: 12),

      // ── Skill chips ───────────────────────────────────────────────────
      if (_mySkills.isEmpty)
        _emptyBox(context, 'No skills yet — add one above')
      else ...[
        Row(children: [
          Icon(Icons.psychology_outlined, color: c.brand, size: 15),
          const SizedBox(width: 7),
          Text('${_mySkills.length} skills found',
              style:
                  GoogleFonts.workSans(fontSize: 12, color: c.textSecondary)),
        ]),
        const SizedBox(height: 10),
        Wrap(
            spacing: 7,
            runSpacing: 7,
            children: _mySkills
                .map((s) => _removableNeutralChip(context, s,
                    onRemove: () => _removeSkill(s)))
                .toList()),
      ],
    ]);
  }

  // ── Step 2B: Certs (with add input) ──────────────────────────────────────

  Widget _buildCertChips(BuildContext context) {
    final c = AppColors.of(context);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Add cert input ────────────────────────────────────────────────
      _addItemRow(
        context,
        controller: _addCertCtrl,
        hint: 'Add a certification to your profile…',
        onAdd: _addCertFromField,
      ),
      const SizedBox(height: 12),

      // ── Cert chips ────────────────────────────────────────────────────
      if (_myCerts.isEmpty)
        _emptyBox(context, 'No certifications yet — add one above')
      else ...[
        Row(children: [
          Icon(Icons.verified_outlined, color: AppTheme.amber500, size: 15),
          const SizedBox(width: 7),
          Text('${_myCerts.length} certifications found',
              style:
                  GoogleFonts.workSans(fontSize: 12, color: c.textSecondary)),
        ]),
        const SizedBox(height: 10),
        Wrap(
            spacing: 7,
            runSpacing: 7,
            children: _myCerts
                .map((cert) => _removableNeutralChip(context, cert,
                    onRemove: () => _removeCert(cert),
                    color: AppTheme.amber500))
                .toList()),
      ],
    ]);
  }

  // ── Step 3: Top 5 ─────────────────────────────────────────────────────────

  Widget _buildTop5(BuildContext context) {
    final matches = widget.record.top5Matches;
    if (matches.isEmpty) {
      return _emptyBox(context, 'No career matches available');
    }
    return Column(
      children: matches.asMap().entries.map((e) {
        return Padding(
          padding: EdgeInsets.only(bottom: e.key < matches.length - 1 ? 12 : 0),
          child: _Top5Card(
            match: e.value,
            isTop: e.key == 0,
            mySkills: _mySkills,
            onAddSkill: _addSkill,
          ),
        );
      }).toList(),
    );
  }

  // ── Step 4: Quality check ─────────────────────────────────────────────────

  Widget _buildQualityCheck(BuildContext context) {
    final c = AppColors.of(context);
    final scoreValue =
        double.tryParse(widget.record.faissScore.replaceAll('%', '').trim()) ??
            0;
    final isPassing = scoreValue >= 99.5;
    final color = isPassing ? AppTheme.green500 : AppTheme.red500;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: c.navy800,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            isPassing ? Icons.verified_rounded : Icons.warning_amber_rounded,
            color: color,
            size: 24,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Analysis complete',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              isPassing
                  ? 'Your results were stored and verified successfully'
                  : 'Something went wrong saving your results — try again',
              style: GoogleFonts.workSans(fontSize: 12, color: c.textSecondary),
            ),
          ],
        )),
        Text(isPassing ? '✓' : '!',
            style: GoogleFonts.fraunces(
                fontSize: 22, fontWeight: FontWeight.w700, color: color)),
      ]),
    );
  }

  // ── Shared helpers ────────────────────────────────────────────────────────

  /// Reusable text field + Add button row
  Widget _addItemRow(
    BuildContext context, {
    required TextEditingController controller,
    required String hint,
    required VoidCallback onAdd,
  }) {
    final c = AppColors.of(context);
    return Row(children: [
      Expanded(
        child: TextFormField(
          controller: controller,
          style: GoogleFonts.workSans(fontSize: 13, color: c.textPrimary),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle:
                GoogleFonts.workSans(fontSize: 13, color: c.textTertiary),
            prefixIcon: Icon(Icons.add_circle_outline_rounded,
                color: c.textTertiary, size: 18),
            contentPadding:
                const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
            isDense: true,
          ),
          onFieldSubmitted: (_) => onAdd(),
          textInputAction: TextInputAction.done,
        ),
      ),
      const SizedBox(width: 8),
      ElevatedButton(
        onPressed: onAdd,
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        child: Text('Add',
            style: GoogleFonts.fraunces(
                fontSize: 13, fontWeight: FontWeight.w700)),
      ),
    ]);
  }

  /// Neutral chip with an × remove button (used for skills + certs lists)
  Widget _removableNeutralChip(
    BuildContext context,
    String label, {
    required VoidCallback onRemove,
    Color? color,
  }) {
    final c = AppColors.of(context);
    final chipColor = color ?? c.brand;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: chipColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: chipColor.withOpacity(0.25)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(label,
            style: GoogleFonts.workSans(
                fontSize: 12, color: chipColor, fontWeight: FontWeight.w500)),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: onRemove,
          child: Icon(Icons.close_rounded, size: 13, color: chipColor),
        ),
      ]),
    );
  }

  Widget _metaRow(BuildContext context, String key, String value) {
    final c = AppColors.of(context);
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(key, style: Theme.of(context).textTheme.bodyMedium),
      Text(value,
          style: GoogleFonts.workSans(
              fontSize: 12,
              color: c.textSecondary,
              fontWeight: FontWeight.w500)),
    ]);
  }

  Widget _emptyBox(BuildContext context, String msg) {
    final c = AppColors.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: c.navy800,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.cardBorder),
      ),
      child: Text(msg, style: Theme.of(context).textTheme.bodyMedium),
    );
  }
}

// ── Career match expandable card ──────────────────────────────────────────────

class _Top5Card extends StatefulWidget {
  final Top5Match match;
  final bool isTop;
  final List<String> mySkills;
  final void Function(String skill) onAddSkill;

  const _Top5Card({
    required this.match,
    required this.isTop,
    required this.mySkills,
    required this.onAddSkill,
  });

  @override
  State<_Top5Card> createState() => _Top5CardState();
}

class _Top5CardState extends State<_Top5Card>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  late AnimationController _ctrl;
  late Animation<double> _expandAnim;
  late List<String> _unmatchedSkills;
  final _addSkillCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _expanded = widget.isTop;
    _unmatchedSkills = List<String>.from(widget.match.unmatchedSkills);
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 250));
    _expandAnim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
    if (_expanded) _ctrl.value = 1.0;
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _addSkillCtrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _expanded = !_expanded);
    _expanded ? _ctrl.forward() : _ctrl.reverse();
  }

  void _addMissingSkill() {
    final skill = _addSkillCtrl.text.trim();
    if (skill.isEmpty) return;
    if (_unmatchedSkills
        .map((s) => s.toLowerCase())
        .contains(skill.toLowerCase())) {
      _addSkillCtrl.clear();
      return;
    }
    setState(() => _unmatchedSkills.add(skill));
    _addSkillCtrl.clear();
  }

  void _removeMissingSkill(String skill) =>
      setState(() => _unmatchedSkills.remove(skill));

  /// Move a missing skill up into the user's skills list
  void _promoteSkill(String skill) {
    widget.onAddSkill(skill);
    setState(() => _unmatchedSkills.remove(skill));
  }

  Color get _rankColor => switch (widget.match.rank) {
        1 => AppTheme.teal500,
        2 => AppTheme.green500,
        3 => AppTheme.amber500,
        _ => AppColors.of(context).textTertiary,
      };

  @override
  Widget build(BuildContext context) {
    final m = widget.match;
    final c = AppColors.of(context);

    return Container(
      decoration: BoxDecoration(
        color: c.navy800,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: widget.isTop ? c.brand.withOpacity(0.35) : c.cardBorder,
          width: widget.isTop ? 1.5 : 1,
        ),
      ),
      child: Column(children: [
        // ── Header row ────────────────────────────────────────────────
        GestureDetector(
          onTap: _toggle,
          behavior: HitTestBehavior.opaque,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: _rankColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text('#${m.rank}',
                      style: GoogleFonts.fraunces(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: _rankColor)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(m.title,
                      style: Theme.of(context).textTheme.titleMedium,
                      overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(
                    m.industry.isNotEmpty
                        ? m.industry
                        : '${m.groundTruthCount} skills required',
                    style: GoogleFonts.workSans(
                        fontSize: 11, color: c.textTertiary),
                  ),
                ],
              )),
              const SizedBox(width: 10),
              AccuracyRing(accuracy: m.nlpAccuracy, size: 48),
              const SizedBox(width: 8),
              AnimatedRotation(
                turns: _expanded ? 0.5 : 0,
                duration: const Duration(milliseconds: 250),
                child: Icon(Icons.keyboard_arrow_down_rounded,
                    color: c.textTertiary, size: 20),
              ),
            ]),
          ),
        ),

        // ── Expanded body ──────────────────────────────────────────────
        SizeTransition(
          sizeFactor: _expandAnim,
          child: Column(children: [
            Divider(height: 1, color: c.divider, indent: 14, endIndent: 14),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Why this role fits ────────────────────────────────
                  if (m.fitReason.isNotEmpty) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: c.brand.withOpacity(0.07),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: c.brand.withOpacity(0.2)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.lightbulb_outline_rounded,
                              color: c.brandSoft, size: 14),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              m.fitReason,
                              style: GoogleFonts.workSans(
                                fontSize: 12,
                                color: c.brandSoft,
                                height: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                  ],

                  // ── Skills you already have ───────────────────────────
                  if (m.matchedSkills.isNotEmpty) ...[
                    _sectionLabel(
                        context,
                        Icons.check_circle_outline_rounded,
                        AppTheme.green500,
                        'Skills you already have (${m.matchedSkills.length})'),
                    const SizedBox(height: 8),
                    Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: m.matchedSkills
                            .map((s) => SkillChip(
                                label: s, type: SkillChipType.matched))
                            .toList()),
                    const SizedBox(height: 14),
                  ],

                  // ── Skills to develop (tap + to add to your skills) ───
                  _sectionLabel(
                      context,
                      Icons.radio_button_unchecked_rounded,
                      AppTheme.red500,
                      'Skills to develop (${_unmatchedSkills.length})'),
                  const SizedBox(height: 4),
                  Text(
                    'Tap + on any skill to add it to your profile',
                    style: GoogleFonts.workSans(
                        fontSize: 11, color: c.textTertiary),
                  ),
                  const SizedBox(height: 8),

                  // Add missing skill text input
                  Row(children: [
                    Expanded(
                      child: TextFormField(
                        controller: _addSkillCtrl,
                        style: GoogleFonts.workSans(
                            fontSize: 12, color: c.textPrimary),
                        decoration: InputDecoration(
                          hintText: 'Add a missing skill…',
                          hintStyle: GoogleFonts.workSans(
                              fontSize: 12, color: c.textTertiary),
                          prefixIcon: Icon(Icons.add_rounded,
                              color: c.textTertiary, size: 16),
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 12),
                          isDense: true,
                        ),
                        onFieldSubmitted: (_) => _addMissingSkill(),
                        textInputAction: TextInputAction.done,
                      ),
                    ),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: _addMissingSkill,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: c.brand,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text('Add',
                            style: GoogleFonts.fraunces(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? AppColors.of(context).navy900
                                    : Colors.white)),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 8),

                  if (_unmatchedSkills.isEmpty)
                    Text('No missing skills — great!',
                        style: GoogleFonts.workSans(
                            fontSize: 12, color: c.textTertiary))
                  else
                    Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: _unmatchedSkills
                            .map((s) => _missingSkillChip(context, s))
                            .toList()),
                ],
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  /// Missing skill chip — shows × to remove and + to promote to My Skills
  Widget _missingSkillChip(BuildContext context, String skill) {
    final alreadyAdded = widget.mySkills
        .map((s) => s.toLowerCase())
        .contains(skill.toLowerCase());

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: alreadyAdded
            ? AppTheme.green500.withOpacity(0.08)
            : AppTheme.red500.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: alreadyAdded
              ? AppTheme.green500.withOpacity(0.35)
              : AppTheme.red500.withOpacity(0.3),
        ),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(skill,
            style: GoogleFonts.workSans(
                fontSize: 11,
                color: alreadyAdded ? AppTheme.green500 : AppTheme.red400,
                fontWeight: FontWeight.w500)),
        const SizedBox(width: 5),
        // + button — adds to My Skills (grayed out if already there)
        GestureDetector(
          onTap: alreadyAdded ? null : () => _promoteSkill(skill),
          child: Icon(
            alreadyAdded
                ? Icons.check_circle_rounded
                : Icons.add_circle_rounded,
            size: 14,
            color: alreadyAdded ? AppTheme.green500 : AppTheme.red400,
          ),
        ),
        const SizedBox(width: 3),
        // × button — removes from missing list
        GestureDetector(
          onTap: () => _removeMissingSkill(skill),
          child:
              const Icon(Icons.close_rounded, size: 13, color: AppTheme.red400),
        ),
      ]),
    );
  }

  Widget _sectionLabel(
      BuildContext context, IconData icon, Color color, String label) {
    return Row(children: [
      Icon(icon, color: color, size: 14),
      const SizedBox(width: 6),
      Text(label,
          style: GoogleFonts.fraunces(
              fontSize: 12, fontWeight: FontWeight.w600, color: color)),
    ]);
  }
}
