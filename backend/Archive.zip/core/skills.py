"""
core/skills.py
==============
Stage 2 — Skill extraction.

Locates the SKILLS section in resume text, segments it, calls the LLM,
then canonicalises results against the Firestore allowlist.
"""

from __future__ import annotations

import logging
import re
from typing import Optional

from rapidfuzz import fuzz

from config import BLOB_FUZZY_THRESHOLD
from core.utils import (
    normalize,
    llm_extract_list,
    build_allow_norm_sorted,
    canonicalize,
    direct_scan_section,
    fuzzy_scan,
)
from core.ocr_correction import (
    OcrCorrector,
    build_ocr_corrector,
    apply_ocr_corrections,
)

log = logging.getLogger(__name__)

# Module-level allowlist cache for the debug path in main.py
_cached_allowlist: list[str] = []

# ── Section boundary regexes ──────────────────────────────────────────────────

_SKILL_HEADING_RE = re.compile(
    r"^(skills?|technical\s+skills?|core\s+competenc\w+|technologies|"
    r"tools?\s+&?\s*technologies?|expertise|proficienc\w+)",
    re.I | re.M,
    )
_SKILLS_END_RE = re.compile(
    r"^\s*(certifications?|licen[cs]es?\s*(&|and)?\s*certifications?|"
    r"professional\s+certifications?|credentials?|accreditations?|"
    r"experience|education|employment|projects?|awards?|publications?|"
    r"references?|volunteer|languages?|interests?|activities|summary|objective)",
    re.I | re.M,
    )

_SKILLS_SYSTEM = (
    "You are a precision resume parser. Your task is to identify professional skills. "
    "1. Look for the 'SKILLS' section in the text and extract those items first. "
    "2. Cross-reference with the 'WORK EXPERIENCE' to validate and find additional tools mentioned. "
    "3. IGNORE single-letter artifacts (like 'C', 'R') or two-letter acronyms (like 'AI', 'ML') "
    "UNLESS they are clearly written as distinct skills in the document. "
    "4. Format as a JSON array of strings. Standardize names (e.g., 'Microson' to 'Microsoft'). "
    "Output ONLY the JSON array."
)


# ── OCR blob segmenter ────────────────────────────────────────────────────────

def split_ocr_blob(line: str, allowlist: list[str]) -> list[str]:
    """
    Segment a collapsed single-line OCR blob into individual skill phrases
    using greedy longest-match fuzzy scanning against the allowlist.
    """
    if not allowlist or not line.strip():
        return [line.strip()] if line.strip() else []

    sorted_allow = sorted(allowlist, key=lambda a: len(a.split()), reverse=True)
    norm_allow   = [(normalize(a), a) for a in sorted_allow]
    max_win      = max(len(a.split()) for a in sorted_allow) if sorted_allow else 1

    tokens  = line.split()
    n       = len(tokens)
    result: list[str] = []
    i = 0

    while i < n:
        best_canon: str | None = None
        best_len:   int        = 0

        for win_len in range(min(max_win, n - i), 0, -1):
            window      = " ".join(tokens[i : i + win_len])
            window_norm = normalize(window)

            if len(window_norm) < 3:
                continue

            wlen = len(window_norm)
            if wlen <= 5:
                effective_threshold = BLOB_FUZZY_THRESHOLD - 10
            elif wlen <= 9:
                effective_threshold = BLOB_FUZZY_THRESHOLD - 5
            else:
                effective_threshold = BLOB_FUZZY_THRESHOLD

            for akey, aval in norm_allow:
                score = max(
                    fuzz.token_sort_ratio(window_norm, akey),
                    fuzz.ratio(window_norm, akey),
                )
                if score >= effective_threshold:
                    best_canon = aval
                    best_len   = win_len
                    break

            if best_canon:
                break

        if best_canon:
            result.append(best_canon)
            i += best_len
        else:
            raw_tok = tokens[i].strip(".,;:()[]")
            if raw_tok:
                result.append(raw_tok)
            i += 1

    return result


# ── Skills section extractor ──────────────────────────────────────────────────

def extract_skills_section(
        text:          str,
        allowlist:     list[str] | None = None,
        is_native_pdf: bool = False,
) -> str:
    """
    Return the skills section as a comma-separated string.
    Skips the early-exit guard when is_native_pdf=True.
    """
    m = _SKILL_HEADING_RE.search(text)
    if not m:
        return ""
    rest = text[m.end():]

    end_m = _SKILLS_END_RE.search(rest)
    block = rest[: end_m.start()].strip() if end_m else rest.strip()

    raw_lines = block.splitlines()

    if is_native_pdf:
        kept_lines = [line.strip() for line in raw_lines if line.strip()]
    else:
        kept_lines: list[str] = []
        for line in raw_lines:
            stripped = line.strip()
            if not stripped:
                continue
            words = stripped.split()
            if (kept_lines
                    and len(words) >= 3
                    and sum(1 for w in words if w[0].isupper()) >= 2):
                break
            kept_lines.append(stripped)

    if not kept_lines:
        return ""

    joined_block = "\n".join(kept_lines)
    _BULLET_RE   = re.compile(r"^\s*[\u2022\-\*\u25e6\u25aa]|\s*\d+\.\s+", re.M)
    entries: list[str] = []

    if "," in joined_block:
        for line in kept_lines:
            for part in re.split(r"\s*,\s*", line):
                if part.strip():
                    entries.append(part.strip())
    elif ";" in joined_block:
        for line in kept_lines:
            for part in re.split(r"\s*;\s*", line):
                if part.strip():
                    entries.append(part.strip())
    elif "|" in joined_block:
        for line in kept_lines:
            for part in line.split("|"):
                if part.strip():
                    entries.append(part.strip())
    elif _BULLET_RE.search(joined_block):
        for line in kept_lines:
            clean = re.sub(r"^\s*[\u2022\-\*\u25e6\u25aa]\s*|\s*\d+\.\s+", "", line).strip()
            if clean:
                entries.append(clean)
    elif len(kept_lines) > 1:
        entries = [line.strip() for line in kept_lines if line.strip()]
    else:
        blob = kept_lines[0] if kept_lines else ""
        if blob:
            effective_allowlist = allowlist if allowlist is not None else _cached_allowlist
            entries = split_ocr_blob(blob, effective_allowlist) if effective_allowlist else [blob]

    return ", ".join(entries)


# ── Public extraction API ─────────────────────────────────────────────────────

def discover_skills_dynamically(
        resume_text:   str,
        jobs_corpus:   list[dict],
        extra_skills:  list[str] | None = None,
        is_native_pdf: bool = False,
) -> list[str]:
    """
    Stage 2 — skill extraction via Llama (HF Inference API).

    1. Build corpus allowlist.
    2. Build OcrCorrector.
    3. Extract skills section with rule-based locator.
    4. Call LLM for extraction.
    5. Canonicalise LLM output.
    6. Direct scan to recover anything the LLM missed.
    7. Fuzzy fallback if both produce nothing.
    """
    global _cached_allowlist

    allowlist: set[str] = set()
    for job in jobs_corpus:
        allowlist.update(job.get("required_skills", []))
    if extra_skills:
        allowlist.update(extra_skills)
    allowlist_list = sorted(allowlist)
    allow_norm     = {normalize(a): a for a in allowlist_list}
    sorted_pairs   = build_allow_norm_sorted(allowlist_list)
    corrector      = build_ocr_corrector(allowlist_list)

    _cached_allowlist = allowlist_list

    section = (
            extract_skills_section(
                resume_text,
                allowlist=allowlist_list,
                is_native_pdf=is_native_pdf,
            )
            or resume_text[:3000]
    )

    user_prompt = (
        f"Extract every technical skill, programming language, framework, tool, "
        f"methodology, and soft skill from this resume section.\n\n"
        f"The skills are listed as comma-separated tokens. Each token or short "
        f"phrase between commas is a distinct skill candidate — treat each one "
        f"individually and standardize any misspelled or OCR-garbled names "
        f"(e.g. 'Microson' -> 'Microsoft', 'Azuie' -> 'Azure').\n\n"
        f"Resume section (comma-separated):\n{section[:2500]}\n\n"
        f"Return ONLY a JSON array of skill name strings. No other text."
    )

    raw = llm_extract_list(_SKILLS_SYSTEM, user_prompt, "SKILLS")

    seen:      set[str]  = set()
    canonical: list[str] = []

    for skill in raw:
        corrected = apply_ocr_corrections(skill, corrector)
        canon     = canonicalize(
            corrected, allow_norm, threshold=75,
            _sorted_pairs=sorted_pairs, corrector=corrector,
        )
        if normalize(canon) == normalize(corrected) and normalize(canon) not in allow_norm:
            log.debug(f"[Skills/LLM] Dropped non-allowlist item: {skill!r}")
            continue
        cn = normalize(canon)
        if cn and cn not in seen:
            seen.add(cn)
            canonical.append(canon)

    for hit in direct_scan_section(section, sorted_pairs, threshold=82, corrector=corrector, allow_norm=allow_norm):
        hn = normalize(hit)
        if hn and hn not in seen:
            seen.add(hn)
            canonical.append(hit)

    if not canonical:
        log.info("[Skills] LLM + direct scan produced nothing — fuzzy fallback.")
        canonical = fuzzy_scan(section, allowlist_list)

    log.info(f"[Skills] {len(canonical)} skills discovered.")
    return canonical